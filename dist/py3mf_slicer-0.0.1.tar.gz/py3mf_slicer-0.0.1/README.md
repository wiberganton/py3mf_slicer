# py3mf_slicer

Provides functions useful to slice 3mf files
